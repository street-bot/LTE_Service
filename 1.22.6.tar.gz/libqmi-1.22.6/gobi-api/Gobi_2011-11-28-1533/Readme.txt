Gobi Extensible API 2011-11-28-1533

This readme covers important information concerning 
the Gobi Extensible API.

Table of Contents

1. What's new in this release
2. Known issues
3. Build steps

-------------------------------------------------------------------------------

1. WHAT'S NEW

Initial Release (Gobi Extensible API 2011-11-28-1533)
a. Initial beta code release

-------------------------------------------------------------------------------

2. KNOWN ISSUES

No known issues.
         
-------------------------------------------------------------------------------

3. BUILD STEPS

a. Start in the 'GobiConnectionMgmt' folder
b. For Android, run:
      make Android ANDROID_PATH=<path to android toolchain>
   For x86, run:
      make

-------------------------------------------------------------------------------



